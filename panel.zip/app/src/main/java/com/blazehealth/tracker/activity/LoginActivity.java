package com.blazehealth.tracker.activity;


import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import com.blazehealth.tracker.libhelper.DownloadZip;
import com.blazehealth.tracker.server.ApiServer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;

import android.widget.Switch;
import static com.blazehealth.tracker.activity.LoginActivity.Sufii;

import static com.blazehealth.tracker.server.ApiServer.activity;
import static com.blazehealth.tracker.server.ApiServer.getOwner;
import static com.blazehealth.tracker.server.ApiServer.getTelegram;
import static com.blazehealth.tracker.server.ApiServer.mainURL;
import static com.blazehealth.tracker.server.ApiServer.fdjhvf;
import static com.blazehealth.tracker.server.ApiServer.checkSuspiciousAppsNative;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.core.content.res.ResourcesCompat;


import android.content.Context;
import android.content.SharedPreferences;
import android.widget.CompoundButton;
import android.widget.Switch;

import android.content.ClipData;
import com.blazehealth.tracker.BuildConfig;

import com.blazehealth.tracker.utils.FPrefs;
import com.blazehealth.tracker.R;
import com.blazehealth.tracker.utils.ActivityCompat;
import com.blazehealth.tracker.utils.FLog;

import android.view.Gravity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.blazehealth.tracker.utils.myTools;


//import com.XSaad_Admin.tastytoast.TastyToast;
import android.widget.CompoundButton;
import org.lsposed.lsparanoid.Obfuscate;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import android.os.Handler;
import android.os.Looper;

@Obfuscate
public class LoginActivity extends ActivityCompat {

    static {
        
            System.loadLibrary("BLAZEBOX");
}


    public static boolean mahyong = false;
    private static final String UPDATE_URL = URLJSON();
    private boolean isDownloadComplete = false;
    private boolean updateCheckComplete = false;
    private static final String QUESTION = "Q: %s";
    private static final String ANSWER = "A: %s";
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    private static final String USER = "USER";
    private static final String PASS = "PASS";
    public static boolean Sufii = false;
    private ImageView showpassword;
    private static String ModeSelect;
    public static String USERKEY, PASSKEY;
    CardView btnSignIn;
    private FPrefs prefs;
    public static native String FixCrash();
    static myTools m;
    

    public static boolean dxdr = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        m = new myTools(this);
        setTheme(m.geInt("myTheme","myTheme",R.style.AppTheme));
        super.onCreate(savedInstanceState);
        setFullScreen();
        setLightStatusBar(this);
        setContentView(R.layout.activity_login);
      /*  if (!mahyong){
            finish();
            finishActivity(1);
        }*/
     //  new DownloadZip(LoginActivity.this).execute("1", FixCrash());
        //checkForNewVersion();
        OverlayPermision();
        initDesign();
     //   Intent intent = new Intent(Intent.ACTION_VIEW);
      //  intent.setData(Uri.parse(getTelegram()));
   //     startActivity(intent);

        final Spinner sp = findViewById(R.id.splang);
        String[] pp = new String[]{
                getString(R.string.jlog2), // English
                getString(R.string.jlog3), // Chinese
                getString(R.string.jlog5), // Arabic
                getString(R.string.jlog6), // Hindi
                getString(R.string.jlog7)  // Russian
        };


        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(R.attr.black, typedValue, true);
        int textColor = typedValue.data;

        Typeface customFont = ResourcesCompat.getFont(this, R.font.cof);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, pp) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView textView = (TextView) super.getView(position, convertView, parent);
                textView.setTextColor(textColor);
                textView.setTypeface(customFont);
                return textView;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView textView = (TextView) super.getDropDownView(position, convertView, parent);
                textView.setTextColor(textColor);
                textView.setTypeface(customFont);
                return textView;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);

        sp.setSelection(getLanguageIndex(m.getSt("myLang", "mapLang", "en")), false);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedText = (String) parent.getItemAtPosition(position);
                String newLang = "";

                if (selectedText.equals(getString(R.string.jlog2))) newLang = "en";
                else if (selectedText.equals(getString(R.string.jlog3))) newLang = "zh";
                else if (selectedText.equals(getString(R.string.jlog5))) newLang = "ar";
                else if (selectedText.equals(getString(R.string.jlog6))) newLang = "hi";
                else if (selectedText.equals(getString(R.string.jlog7))) newLang = "ru";

                final String finalNewLang = newLang;

                if (!finalNewLang.isEmpty() && !finalNewLang.equals(m.getSt("myLang", "mapLang", "en"))) {
                    m.setLocale(LoginActivity.this, finalNewLang);
                    m.setSt("myLang", "mapLang", finalNewLang);

                    sp.postDelayed(() -> {
                        sp.setSelection(getLanguageIndex(finalNewLang), false);
                        recreate();
                    }, 100);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    public static void DwnSocket(LoginActivity activity) {

    }

    public void initDesign() {
        prefs = FPrefs.with(this);
        final Context m_Context = this;
        TextView textUsername = findViewById(R.id.textUsername);
        TextView textPassword = findViewById(R.id.textPassword);
        // Get references to the TextInputLayout and TextInputEditTexts
        TextInputLayout emailLayout = findViewById(R.id.email_layout);  // Assuming this is where endIconDrawable is used
        MaterialButton btnSignIn = findViewById(R.id.loginBtn);
        // LinearLayout timg = findViewById(R.id.timg);
        //showpassword = findViewById(R.id.viewpw);
        textUsername.setText(prefs.read(USER, ""));
        textPassword.setText(prefs.read(PASS, ""));
        Intent intent = getIntent();

        btnSignIn.setEnabled(true); //

        btnSignIn.setOnClickListener(
    new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TextView textUsername = findViewById(R.id.textUsername);
            TextView textPassword = findViewById(R.id.textPassword);
            
            if (!textUsername.getText().toString().isEmpty()
                    && !textPassword.getText().toString().isEmpty()) {
                
                prefs.write(USER, textUsername.getText().toString());
                prefs.write(PASS, textPassword.getText().toString());
                
                String userKey = textUsername.getText().toString().trim();
                String passKey = textPassword.getText().toString().trim();
                            //Login(LoginActivity.this, userKey);
                           // USERKEY = userKey;
                            PASSKEY = passKey;
                         //   String userKey = textUsername.getText().toString().trim();

            // Show the loading dialog
            AlertDialog loadingDialog = showLoadingDialog();

            // Run login process
            Login(LoginActivity.this, userKey, loadingDialog);  // Pass dialog to dismiss later
            USERKEY = userKey;
            }

            TextView errorUsername = findViewById(R.id.error_username);
            TextView errorPassword = findViewById(R.id.error_password);

            if (textUsername.getText().toString().isEmpty()) {
                errorUsername.setText(getString(R.string.please_enter_username));
                errorUsername.setVisibility(View.VISIBLE);
            } else {
                errorUsername.setVisibility(View.GONE);
            }

            if (textPassword.getText().toString().isEmpty()) {
                errorPassword.setText(getString(R.string.please_enter_password));
                errorPassword.setVisibility(View.VISIBLE);
            } else {
                errorPassword.setVisibility(View.GONE);
            }
        }
    });


        EditText editText = findViewById(R.id.textPassword);
        editText.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                ((TextInputLayout) findViewById(R.id.email_layout)).setHintTextColor(ColorStateList.valueOf(getResources().getColor(R.color.main)));
            }
        });

        EditText editTextpass = findViewById(R.id.textUsername);
        editTextpass.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                ((TextInputLayout) findViewById(R.id.password_layout)).setHintTextColor(ColorStateList.valueOf(getResources().getColor(R.color.main)));
            }
        });

// Set the endIcon click listener for the TextInputLayout (paste functionality)
        emailLayout.setEndIconOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboardManager.hasPrimaryClip()) {
            ClipData clipData = clipboardManager.getPrimaryClip();
            if (clipData != null && clipData.getItemCount() > 0) {
                String copiedText = clipData.getItemAt(0).coerceToText(getApplicationContext()).toString();
                textUsername.setText(copiedText);
                textPassword.setText(copiedText);
            } else {
                Toast.makeText(m_Context, "Clipboard is empty!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(m_Context, "No text in clipboard!", Toast.LENGTH_SHORT).show();
        }
    }
});



        TextView getversion = findViewById(R.id.registerText);
        getversion.setText("v" + BuildConfig.VERSION_NAME); // Set versionName


        TextView tg = findViewById(R.id.tg);
        tg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getTelegram()));
                startActivity(intent);
            }
        });

        TextView reset_key_text = findViewById(R.id.reset_key_text);
        reset_key_text.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getOwner()));
                startActivity(intent);
            }
        });

        ImageView bottomImage = findViewById(R.id.bottomImage);
        bottomImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getTelegram()));
                startActivity(intent);
            }
        });
        LoginActivity.setModeSelect("DIAMONDYT");
        Sufii = true;


    }


    private void setLightStatusBar(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        activity.getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
    }

    public static void goLogin(Context context) {
        Intent i = new Intent(context, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }


    public void OverlayPermision() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage(R.string.please_allow_permision_floating);
                builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface p1, int p2) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                    }
                });
                builder.setCancelable(false);
                builder.show();
            }
        }
    }

    private void checkForNewVersion() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(UPDATE_URL);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setConnectTimeout(10000);
                    urlConnection.setReadTimeout(10000);

                    int responseCode = urlConnection.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        Log.d("UpdateCheck", "Raw JSON Response: " + response.toString());

                        JSONObject jsonResponse = new JSONObject(response.toString());
                        String apkUrl = jsonResponse.getString("apk_url");
                        String updateTitle = jsonResponse.getString("update_title");
                        String updateMessage = jsonResponse.getString("update_message");
                        String updateSize = jsonResponse.getString("update_size");
                        String serverVersionName = jsonResponse.getString("version_name");
                        String currentVersionName = BuildConfig.VERSION_NAME;

                        Log.d("UpdateCheck", "Current version name: " + currentVersionName);
                        Log.d("UpdateCheck", "Fetched version name: " + serverVersionName);

                        if (!serverVersionName.equals(currentVersionName)) {
                            Log.d("UpdateCheck", "New version available, showing update dialog.");
                            runOnUiThread(() -> showUpdateDialog(apkUrl, updateTitle, updateMessage, updateSize));
                        } else {
                            Log.d("UpdateCheck", "No new version available.");
                            runOnUiThread(() -> {
                                Toast.makeText(LoginActivity.this, R.string.app_is_up_to_date, Toast.LENGTH_SHORT).show();
                                updateCheckComplete = true;
                                enableNavigationButtons();
                            });
                        }
                    } else {
                        Log.e("UpdateCheck", "Failed to fetch update info: Server returned " + responseCode);
                        runOnUiThread(() -> {
                            Toast.makeText(LoginActivity.this, R.string.failed_to_check_for_updates, Toast.LENGTH_SHORT).show();
                            updateCheckComplete = true;
                            enableNavigationButtons();
                        });
                    }
                    urlConnection.disconnect();
                } catch (Exception e) {
                    Log.e("UpdateCheck", "Error: " + e.getMessage());
                    runOnUiThread(() -> {
                        Toast.makeText(LoginActivity.this, R.string.error_parsing_update_information_please_try_again_later, Toast.LENGTH_SHORT).show();
                        updateCheckComplete = true;
                        enableNavigationButtons();
                    });
                }
            }
        }).start();
    }


    private void showUpdateDialog(String apkUrl, String updateTitle, String updateMessage, String updateSize) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View updateLayout = getLayoutInflater().inflate(R.layout.apk_update_version, null);
        builder.setView(updateLayout);
        builder.setCancelable(false);

        AlertDialog dialog = builder.create();
        dialog.show();

        TextView titleView = updateLayout.findViewById(R.id.update_title);
        TextView messageView = updateLayout.findViewById(R.id.update_message);
        TextView sizeView = updateLayout.findViewById(R.id.update_size);
        TextView btnNoThanks = updateLayout.findViewById(R.id.btn_no_thanks);
        TextView btnUpdate = updateLayout.findViewById(R.id.btn_update);

        titleView.setText(updateTitle);
        messageView.setText(updateMessage);
        sizeView.setText(getString(R.string.download_size) + updateSize);

        btnNoThanks.setOnClickListener(v -> finishAffinity());

        btnUpdate.setOnClickListener(v -> {
            dialog.dismiss();
            startDownload(apkUrl);
        });
    }

    private void startDownload(String apkUrl) {
        AlertDialog progressDialog = new AlertDialog.Builder(this)
                //.setTitle(getString(R.string.downloading))
                .setView(R.layout.progress_dialog_layout)
                .setCancelable(false)
                .create();

        progressDialog.show();

        ProgressBar progressBar = progressDialog.findViewById(R.id.progressBar);
        TextView progressText = progressDialog.findViewById(R.id.progressText);

        new Thread(() -> {
            try {
                HttpURLConnection connection = (HttpURLConnection) new URL(apkUrl).openConnection();
                connection.setRequestMethod("GET");
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty(getString(R.string.connection), getString(R.string.close_));
                connection.connect();

                int responseCode = connection.getResponseCode();
                if (responseCode != 200) {
                    throw new IOException(getString(R.string.request_code_not_200));
                }

                File outputPath = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "blazehax.apk");

                InputStream inputStream = connection.getInputStream();
                FileOutputStream fileOutputStream = new FileOutputStream(outputPath);
                byte[] data = new byte[1024];
                long total = 0;
                int count;
                while ((count = inputStream.read(data)) != -1) {
                    total += count;
                    long finalTotal = total;
                    runOnUiThread(() -> {
                        float curr = (float) (finalTotal / 1024) / 1024;
                        String txt = String.format(Locale.getDefault(), "Downloading ( %.2fMB )", curr);
                        if (progressText != null) progressText.setText(txt);
                    });
                    fileOutputStream.write(data, 0, count);
                }

                inputStream.close();
                fileOutputStream.flush();
                fileOutputStream.close();
                connection.disconnect();

                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    isDownloadComplete = true;
                    installApk(outputPath);
                });

            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, R.string.failed_to_download_please_check_your_internet_connection, Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }


    private void setFullScreen() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void installApk(File apkFile) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri apkUri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", apkFile);
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finishAffinity();
    }

    // ✅ **Helper Method (Language Code & Index Map)**
    private int getLanguageIndex(String langCode) {
        switch (langCode) {
            case "zh":
                return 1;
            case "ar":
                return 2;
            case "hi":
                return 3;
            case "ru":
                return 4;
            default:
                return 0; // English (Default)
        }
    }

    private void enableNavigationButtons() {
        MaterialButton btnSignIn = findViewById(R.id.loginBtn);


        if (updateCheckComplete) {
            btnSignIn.setEnabled(true);

        }
    }

    public static native String URLJSON();


    public static void setModeSelect(String mode) {
        ModeSelect = mode;
    }

    public static String getModeSelect() {
        return ModeSelect;
    }

    private static void Login(final Context m_Context, final String userKey, final AlertDialog loadingDialog) {
    final Handler loginHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
               // cekl = true;
                loadingDialog.dismiss();  // Hide loading dialog
                Intent i = new Intent(m_Context.getApplicationContext(), MainActivity.class);
                m_Context.startActivity(i);
            } else if (msg.what == 1) {
                loadingDialog.dismiss();  // Hide loading dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(m_Context, 5);
                builder.setTitle("Key Error");
                builder.setMessage(msg.obj.toString());
                builder.setCancelable(false);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        System.exit(0);
                    }
                });
                builder.show();
            }
        }
    };

    new Thread(new Runnable() {
        @Override
        public void run() {
            String result = suckmydick(m_Context, userKey);
            if (result.equals("OK")) {
                loginHandler.sendEmptyMessage(0);
            } else {
                Message msg = new Message();
                msg.what = 1;
                msg.obj = result;
                loginHandler.sendMessage(msg);
            }
        }
    }).start();
}


    
         
private AlertDialog showLoadingDialog() {
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.animation_login, null);
    builder.setView(dialogView);

    AlertDialog dialog = builder.create();
    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    dialog.setCancelable(false);
    dialog.show();
    
    return dialog;  // Return dialog reference
}



/**
 * Function to detect suspicious apps before login.
 */



    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) {
            OverlayPermision();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            InstllUnknownApp();
        } else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES) {
            if (!isPermissionGaranted()) {
                takeFilePermissions();
            }
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(updateBaseContextLocale(newBase));
    }


    private Context updateBaseContextLocale(Context context) {
        myTools m = new myTools(context);
        String savedLang = m.getSt("myLang", "mapLang", "en");
        return m.updateLocale(context, savedLang);
    }
    
    private boolean hfdeeruygg() {
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            Signature[] dgfffgg = packageInfo.signingInfo.getApkContentsSigners();
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            String mbggfd = ApiServer.fdjhvf(); // Get the expected signature from JNI

            for (Signature vffgjigf : dgfffgg) {
                md.update(vffgjigf.toByteArray());
                String ygfddef = bytesToHex(md.digest());

                if (mbggfd.equals(ygfddef)) {
                    return true;
                }
            }
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return false;
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            hexString.append(String.format("%02X", b));
        }
        return hexString.toString();
    }
    
    
    private static native String suckmydick(Context mContext, String userKey);

    class LAdap extends ArrayAdapter<String> {

        Context context;

        private String[] st;


        public LAdap(Context context, String[] st) {
            super(context, R.layout.spin_item, st);
            this.context = context;
            this.st = st;
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            LayoutInflater infl = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = infl.inflate(R.layout.spin_item, null);
            row.setBackgroundColor(0x141B1F);
            TextView t1 = row.findViewById(R.id.tv1);
            t1.setText(st[position]);

            return row;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater infl = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = infl.inflate(R.layout.spin_item, null);
            TextView t1 = row.findViewById(R.id.tv1);
            t1.setText(st[position]);
            return row;
        }


    }
}
