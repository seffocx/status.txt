package com.blazehealth.tracker.floating;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;


import java.io.*;
import java.lang.Process;


import android.annotation.SuppressLint;
import com.blazehealth.tracker.activity.MainActivity;

public class Overlay extends Service {
  
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    WindowManager windowManager;
   static Process process;
    View mainView;
    ESPView overlayView;

   @SuppressLint("StaticFieldLeak")
    private static Overlay Instance;

	static Context ctx;
    @SuppressLint("InflateParams")
    @Override
    public void onCreate() {
        super.onCreate();
        ctx=this;
       Start(ctx,0,1);
        windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        overlayView = new ESPView(ctx);
        DrawCanvas();
    }

    @Override
    public void onDestroy() {
		super.onDestroy();
		Close();

        if(overlayView != null)
        {
            ((WindowManager)ctx.getSystemService(Context.WINDOW_SERVICE)).removeView(overlayView);
            overlayView = null;
        }
		process.destroy();
    }

    public static void Start(final Context context,final int gametype,final int bit) {

        if (Instance == null) {
            Thread t=new Thread(new Runnable() {
					@Override
					public void run(){
						getReady(gametype);

					}
				});
            t.start();

            Thread t2=new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Thread.sleep(0);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						StartDaemon(context,bit);
					}
				});
            t2.start();

        }
    }
    static native boolean getReady(int nameofgame);

	public static void StartDaemon(final Context context,int bit){
		Shell(MainActivity.socket);
	}

    public static void Stop(Context context) {
        Intent intent = new Intent(context, Overlay.class);
        context.stopService(intent);

        Intent floatLogo = new Intent(context, FloatService.class);
        context.stopService(floatLogo);



    }

    private native void Close();
	public static boolean getConfig(String key){
        SharedPreferences sp=ctx.getSharedPreferences("espValue",Context.MODE_PRIVATE);
        return  sp.getBoolean(key,false);
    }
    private void DrawCanvas() {
    int LAYOUT_FLAG;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    } else {
        LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
    }

    final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            0,
            getNavigationBarHeight(),
            LAYOUT_FLAG,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.RGBA_8888);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
    }

    params.gravity = Gravity.TOP | Gravity.START;
    params.x = 0;
    params.y = 0;

    // Use fake recorder params only if MAct.Record is true
 
    windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    windowManager.addView(overlayView, params);
}

    public static native void DrawOn(ESPView espView, Canvas canvas);
    private int getNavigationBarHeight() {
        boolean hasMenuKey = ViewConfiguration.get(this).hasPermanentMenuKey();
        int resourceId = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0 && !hasMenuKey) {
            return getResources().getDimensionPixelSize(resourceId);
        }
        return 0;
    }

	public static void Shell(String str) {

		DataOutputStream dataOutputStream = null;
		try {
			process = Runtime.getRuntime().exec(str);
        } catch (IOException e) {
			e.printStackTrace();
            process = null;
        }
		if (process != null) {
            dataOutputStream = new DataOutputStream(process.getOutputStream());
        }
        try {
            dataOutputStream.flush();
        } catch (IOException e2) {
			e2.printStackTrace();
		}
        try {
            process.waitFor();
        } catch (InterruptedException e3) {
			e3.printStackTrace();
		}
	}
}

