package com.blazehealth.tracker.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import com.blankj.molihuan.utilcode.util.FileUtils;
import com.airbnb.lottie.LottieAnimationView;
import com.blazehealth.tracker.R;
import com.blazehealth.tracker.floating.FloatService;

import java.io.File;
import java.io.IOException;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
//import top.niunaijun.blackbox.utils.FileUtils;

public class InstallActivity {
    private final Context context;
    private final String packageName;
    private final BlackBoxCore blackboxCore;

    public InstallActivity(Context context, String packageName) {
        this.context = context;
        this.packageName = packageName;
        this.blackboxCore = BlackBoxCore.get();
        this.blackboxCore.doCreate();
    }

    public void handleInstallationProcess() {
        boolean isAppInstalledOnDevice = isAppInstalled(packageName);
        boolean isAppInstalledInBlackbox = blackboxCore.isInstalled(packageName, 0);

        if (isAppInstalledInBlackbox) {
            sendStatus("installed_available");
            launchGame();
        } else if (isAppInstalledOnDevice) {
            sendStatus("not_installed_available");
            installGame();
        } else {
            sendStatus("not_installed_unavailable");
        }
    }

    private boolean isAppInstalled(String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void sendStatus(String status) {
        Intent intent = new Intent();
        intent.putExtra("STATUS", status);
        context.sendBroadcast(intent);
    }

    private void launchGame() {
        LayoutInflater inflater = LayoutInflater.from(context);
        View viewLottie = inflater.inflate(R.layout.animation_lottie, null);
        AlertDialog dialogLottie = new AlertDialog.Builder(context, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewLottie)
                .setCancelable(false)
                .create();
        if (dialogLottie.getWindow() != null) {
            dialogLottie.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        LottieAnimationView lottieView = viewLottie.findViewById(R.id.lottie_animation);
        lottieView.setAnimation(R.raw.rocket);
        lottieView.playAnimation();
        dialogLottie.show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (dialogLottie.isShowing()) dialogLottie.dismiss();
            launchApk(packageName);
        }, 3000);
        launchBypassNoRoot();
        new Handler(Looper.getMainLooper()).postDelayed(() -> FloatService.enableESP(context), 10000);
    }

    private void installGame() {
    LayoutInflater inflater = LayoutInflater.from(context);
    View viewLoading = inflater.inflate(R.layout.animation_launch, null);
    AlertDialog dialogLoading = new AlertDialog.Builder(context, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setView(viewLoading)
            .setCancelable(false)
            .create();
    if (dialogLoading.getWindow() != null) {
        dialogLoading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }
    dialogLoading.show();

    new Handler(Looper.getMainLooper()).postDelayed(() -> {
        InstallResult installResult = blackboxCore.installPackageAsUser(packageName, 0);
        if (installResult.success) {
            Toast.makeText(context,
                    context.getString(R.string.install_success),
                    Toast.LENGTH_LONG).show();
            sendStatus("installed_available");
        } else {
            Toast.makeText(context, installResult.msg, Toast.LENGTH_SHORT).show();
        }
        checkAndCopyObbFiles();

        if (dialogLoading.isShowing()) dialogLoading.dismiss();
    }, 2000);
}

    private void checkAndCopyObbFiles() {
        File obbFolder = new File("/storage/emulated/0/SdCard/Android/obb/" + packageName);
        File[] obbFiles = obbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageName + "\\.obb"));

        if (obbFiles == null || obbFiles.length == 0) {
            File sourceFolder = new File("/storage/emulated/0/Android/obb/" + packageName);
            File[] sourceFiles = sourceFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageName + "\\.obb"));

            if (sourceFiles != null && sourceFiles.length > 0) {
                new CopyObbTask().execute(sourceFiles[0].getAbsolutePath(), packageName);
            }
        }
    }

    private void launchBypassNoRoot() {
        // Your bypass implementation
    }

    private class CopyObbTask extends AsyncTask<String, Integer, File> {
    String message;

    @Override
    protected File doInBackground(String... params) {
        String sourcePath = params[0];
        File source = new File(sourcePath);
        String filename = sourcePath.substring(sourcePath.lastIndexOf("/") + 1);
        File destination = new File("/storage/emulated/0/SdCard/Android/obb/" + params[1] + "/" + filename);

        try {
            // ✅ reference ke hisaab se path-based copy (ya agar file-based supported hai to usko hi rakho)
            FileUtils.copy(source.getAbsolutePath(), destination.getAbsolutePath());
        } catch (Exception e) {   // 👈 IOException ki jagah Exception catch karo
            message = e.getMessage();
        }

        return destination;
    }

    @Override
    protected void onPostExecute(File result) {
        if (result.exists()) {
            Toast.makeText(context,
                    context.getString(R.string.obb_copied),
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context,
                    message,
                    Toast.LENGTH_LONG).show();
        }
    }
}

    public void launchApk(String packageName) {
    if (!isPackageInstalled(packageName)) {
        Toast.makeText(context,
                context.getString(R.string.not_installed),
                Toast.LENGTH_LONG).show();
        return;
    }
    try {
        blackboxCore.launchApk(packageName, 0);
    } catch (Exception e) {
        throw new RuntimeException(e);
    }
}

    public void uninstallApp() {
    blackboxCore.uninstallPackageAsUser(packageName, 0);
    Toast.makeText(context,
            context.getString(R.string.successfully_uninstalled),
            Toast.LENGTH_LONG).show();
}

    public boolean isRunning() {
        return blackboxCore.isInstalled(packageName, 0);
    }

    public void stopRunningApp() {
        blackboxCore.stopPackage(packageName, 0);
    }

    public ApplicationInfo getApplicationInfoContainer() {
        if (!isPackageInstalled(packageName)) {
            Toast.makeText(context, R.string.app_not_installed_please_install_first, Toast.LENGTH_LONG).show();
            return null;
        }
        return null;
    }

    private boolean isPackageInstalled(String packageName) {
        return blackboxCore.isInstalled(packageName, 0);
    }
}
