package com.blazehealth.tracker.activity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.os.StatFs;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;

import androidx.appcompat.app.AppCompatDelegate;
//import com.XSaad_Admin.tastytoast.TastyToast;

import com.blankj.molihuan.utilcode.util.FileUtils;

import com.airbnb.lottie.LottieAnimationView;
import com.blazehealth.tracker.utils.InstallActivity;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationView;

import com.blazehealth.tracker.BoxApplication;

import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.AsyncTask;
import android.graphics.Color;

import static com.blazehealth.tracker.activity.LoginActivity.PASSKEY;
import static com.blazehealth.tracker.activity.LoginActivity.USERKEY;
import static com.blazehealth.tracker.activity.LoginActivity.Sufii;
import static com.blazehealth.tracker.activity.LoginActivity.mahyong;
import static com.blazehealth.tracker.server.ApiServer.EXP;

import static com.blazehealth.tracker.server.ApiServer.getOwner;
import static com.blazehealth.tracker.server.ApiServer.mainURL;
import static com.blazehealth.tracker.server.ApiServer.getTelegram;
import static com.blazehealth.tracker.server.ApiServer.getGrup;
import com.blazehealth.tracker.Component.DownloadZip;

import com.blazehealth.tracker.BuildConfig;
//import com.blazehealth.tracker.utils.UiKit;

import dalvik.annotation.TestTarget;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;

import com.google.android.material.button.MaterialButton;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;

import androidx.appcompat.app.AlertDialog;



import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
//import com.blazehealth.tracker.libhelper.FileHelper;
import android.widget.Toast;

import com.blankj.molihuan.utilcode.util.FileUtils;
import static top.niunaijun.blackbox.core.env.BEnvironment.getDataFilesDir;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.DocumentsContract;



import com.blazehealth.tracker.R;
//import com.blazehealth.tracker.adapter.RecyclerViewAdapter;
import com.blazehealth.tracker.floating.FloatService;
import com.blazehealth.tracker.floating.Overlay;
import com.blazehealth.tracker.floating.ToggleAim;
import com.blazehealth.tracker.floating.ToggleBullet;
import com.blazehealth.tracker.floating.ToggleSimulation;
import com.blazehealth.tracker.floating.FightMode;
//import com.blazehealth.tracker.libhelper.ApkEnv;
import com.blazehealth.tracker.utils.ActivityCompat;
import com.blazehealth.tracker.utils.FLog;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.topjohnwu.superuser.Shell;

import android.view.LayoutInflater;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
//import top.niunaijun.blackbox.utils.FileUtils;

import android.content.Context;
import android.content.pm.PackageInfo;
import com.blazehealth.tracker.utils.myTools;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class MainActivity extends ActivityCompat {

    DrawerLayout drawerLayout;
    ImageView sidebar;

    private GestureDetector gestureDetector;
    
    static myTools m;
    
    public static String socket;
    public static String daemonPath;
    public static boolean fixinstallint = false;
    public static boolean check = false;
    public static int hiderecord = 0;
    static MainActivity instance;
    private long backPressedTime = 0;
    //  public static int game_ver = 0;

    Context ctx;
    InstallResult installResult;
    BlackBoxCore blackboxCore;

    private TextView statusText;


    static {
        
            System.loadLibrary("BLAZEBOX");
}


    private static final int REQUEST_PERMISSIONS = 1;
    private static final int REQUEST_MIC_PERMISSION = 2025;


    int Storage_Permission = 142;
    private static final String PREF_NAME = "espValue";
    private SharedPreferences sharedPreferences;
    String Launch = "Launch";
    String[] appPackage = {"com.tencent.ig", "com.pubg.krmobile", "com.pubg.imobile", "com.twitter.android", "com.facebook.katana", "com.vng.pubgmobile", "com.rekoo.pubgm", "mark.via.gp", "telegram @ayansy3d"};
    String[] googlePackage = {"com.google.android.gms", "com.google.android.gsf", "com.android.vending", "com.google.android.gm", "telegram @UnRealHax"};
    public String nameGame = "PROTECTION GLOBAL";
    public String CURRENT_PACKAGE = "";
    public LinearProgressIndicator progres;
    public CardView enable, disable;
    public static int gameint = 0;
    public static String bypassmode = "manual";
    public static int bitversi = 64;
    public static boolean noroot = false;
    public static int device = 1;
    public static String game = "com.tencent.ig";
    public static String pkg = "com.tencent.ig";
    TextView root;
    public static boolean kernel = false;
    public static boolean Ischeck = false;
    public static boolean modestatus = false;
    public LinearLayout container;

    public static String modeselect;
    public static String typelogin;


    public static MainActivity get() {
        return instance;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        m = new myTools(this);
        setTheme(m.geInt("myTheme","myTheme",R.style.AppTheme));

        setContentView(R.layout.act_main);

//        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(this));
        
        init();

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        blackboxCore = BlackBoxCore.get();
        blackboxCore.doCreate();
        
   //    installViaApkIfNeeded();

        drawerLayout = findViewById(R.id.DrawerLayout);
        sidebar = findViewById(R.id.sidebar);

        ctx = this;
        EnableCars();
        EnableItems();
        initMenu1();
        initMenu2();
        Loadssets();
        devicecheck();
        SettingESP();

        instance = this;
        isLogin = true;
        Checking();

        Makedir();
     //   showLoginHelpDialog();
     //   requestMicPermission();


        sidebar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.open();
            }
        });



        TextView footerVersion = findViewById(R.id.footerversion);
        if (footerVersion != null) {
            String versionName = BuildConfig.VERSION_NAME;
            footerVersion.setText(getString(R.string.app_version_) + versionName);
        }

        TextView mainver = findViewById(R.id.mainver);
        if (footerVersion != null) {
            String versionName = BuildConfig.VERSION_NAME;
            mainver.setText(getString(R.string.app_version_) + versionName);
        }

        LinearLayout menu1 = findViewById(R.id.imenu1);
        LinearLayout menu2 = findViewById(R.id.imenu2);
        ImageView home = findViewById(R.id.imghome);
        ImageView sett = findViewById(R.id.imgsett);
        TextView txtsett = findViewById(R.id.txtsett);
        TextView txthome = findViewById(R.id.txthome);

        NavigationView navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
         @Override
public boolean onNavigationItemSelected(@NonNull MenuItem item) {
    int id = item.getItemId();

    if (id == R.id.logout) {
        drawerLayout.close();
        Intent restartIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (restartIntent != null) {
            restartIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(restartIntent);
            Runtime.getRuntime().exit(0);
        }
    } else if (id == R.id.homei) {
        drawerLayout.close();
        menu1.setVisibility(View.VISIBLE);
        menu2.setVisibility(View.GONE);
        txthome.setTextColor(getResources().getColor(R.color.main));
        txtsett.setTextColor(getResources().getColor(R.color.gray));
        home.setBackgroundResource(R.drawable.ic_home);
        sett.setBackgroundResource(R.drawable.outline_settings_24);
        return true;
    } else if (id == R.id.setti) {
        drawerLayout.close();
        menu1.setVisibility(View.GONE);
        menu2.setVisibility(View.VISIBLE);
        txthome.setTextColor(getResources().getColor(R.color.gray));
        txtsett.setTextColor(getResources().getColor(R.color.main));
        home.setBackgroundResource(R.drawable.ic_home_outline);
        sett.setBackgroundResource(R.drawable.ic_helpon);
        return true;
    } else if (id == R.id.link_tg) {
        drawerLayout.close();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(getTelegram()));
        startActivity(intent);
    } else if (id == R.id.link_community) {
        drawerLayout.close();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(getGrup()));
        startActivity(intent);
    } else if (id == R.id.link_dev) {
        drawerLayout.close();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(getOwner()));
        startActivity(intent);
    } else if (id == R.id.install_gsm) {
        drawerLayout.close();
        BlackBoxCore.get().installGms(0);
        Toast.makeText(MainActivity.this, "Installing GSM...", Toast.LENGTH_LONG).show();

        new Thread(() -> {
            File viaPath = new File(getFilesDir(), "via.apk");
            if (!viaPath.exists()) {
                runOnUiThread(() ->
                    Toast.makeText(MainActivity.this, "File not found!", Toast.LENGTH_LONG).show()
                );
                return;
            }

            InstallResult installResult = BlackBoxCore.get().installPackageAsUser(viaPath, 0);
            runOnUiThread(() -> {
                if (installResult.success) {
                    Toast.makeText(MainActivity.this, "Google installed successfully!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Failed to install Google!", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }
    return false;
}
            
            
            
        });

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                float screenWidth = getResources().getDisplayMetrics().widthPixels;
                float touchArea = screenWidth * 0.6f; // 60% tak swipe enable

                if (e1 != null && e2 != null && e1.getX() < touchArea && e2.getX() > e1.getX()) {
                    drawerLayout.openDrawer(navigationView);
                    return true;
                }
                return false;
            }
        });

        lotti();

    }

public void requestMicPermission() {
    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {

        if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            // User clicked "Don't ask again"
            Toast.makeText(this, "Mic permission blocked. Enable manually in settings.", Toast.LENGTH_LONG).show();
            openAppSettings(); // ✅ now defined
        } else {
            // Request mic permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    REQUEST_PERMISSIONS);
        }

    } else {
        Toast.makeText(this, "Mic permission already granted ✅", Toast.LENGTH_SHORT).show();
    }
}

private void openAppSettings() {
    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
    Uri uri = Uri.fromParts("package", getPackageName(), null);
    intent.setData(uri);
    startActivity(intent);
}

 void lotti() {
        NavigationView navigationView = findViewById(R.id.navigation_view);

        if (navigationView != null) {
            View headerView = navigationView.getHeaderView(0);

            if (headerView != null) {
                final Switch lt = headerView.findViewById(R.id.themeSwitch);
                lt.setChecked(m.getBool("myTheme", "mcTheme", false));

                lt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton p1, boolean p2) {
                        if (p2) {
                            m.setInt("myTheme", "myTheme", R.style.AppTheme2);
                            m.setBool("myTheme", "mcTheme", true);
                            recreate();
                        } else {
                            m.setInt("myTheme", "myTheme", R.style.AppTheme);
                            m.setBool("myTheme", "mcTheme", false);
                            recreate();
                        }
                    }
                });
            }
        }
    }





    public void devicecheck() {
        root = findViewById(R.id.textroot);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd ", Locale.getDefault());
        String currentDateTime = sdf.format(new Date());

        if (Shell.rootAccess()) {
            FLog.info("Root granted");
            modeselect = currentDateTime + "- A" + Build.VERSION.RELEASE;
            root.setText(getString(R.string.root));
            Ischeck = true;
            noroot = true;
            device = 1;
        } else {
            FLog.info("Root not granted");
            modeselect = currentDateTime + "- A" + Build.VERSION.RELEASE;
            root.setText(getString(R.string.notooroot));
            Ischeck = false;
            device = 2;
        }
    }




    

    public void Checking(){
        
                new DownloadZip(this).execute("1", mainURL());
               // verifyApp();
                
        }
    
    

    @SuppressLint({"SetTextI18n", "ResourceType"})
    public void initMenu1() {
        LinearLayout layhome3 = findViewById(R.id.hackkkk);

        MaterialButton esp64Button = findViewById(R.id.esp64);
        MaterialButton esp32Button = findViewById(R.id.esp32);
        MaterialButton systemModeBtn = findViewById(R.id.system);
        MaterialButton kernelModeBtn = findViewById(R.id.kernel);
        MaterialButton espsafe = findViewById(R.id.espsafe);
        MaterialButton espunsafe = findViewById(R.id.espunsafe);

        AppCompatButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
        AppCompatButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
        AppCompatButton InstallKRBtn = findViewById(R.id.InstallKR);
        AppCompatButton InstallVNGBtn = findViewById(R.id.InstallVNG);
        AppCompatButton InstallTWBtn = findViewById(R.id.InstallTW);

        if (Shell.rootAccess()) {
            InstallBgmiBtn.setText(R.string.start_);
            InstallGlobalBtn.setText(R.string.start_);
            InstallKRBtn.setText(R.string.start_);
            InstallVNGBtn.setText(R.string.start_);
            InstallTWBtn.setText(R.string.start_);

        } else {

        }

        TextView keytext = findViewById(R.id.licencekey);

        Shader textShader = new LinearGradient(0, 0, keytext.getPaint().measureText(keytext.getText().toString()), keytext.getTextSize(), new int[]{Color.parseColor("#0a95fc"), Color.parseColor("#04285a")}, null, Shader.TileMode.CLAMP);

        keytext.getPaint().setShader(textShader);

        TextView devicetext = findViewById(R.id.devicetext);

        Shader textShader1 = new LinearGradient(0, 0, keytext.getPaint().measureText(devicetext.getText().toString()), devicetext.getTextSize(), new int[]{Color.parseColor("#0a95fc"), Color.parseColor("#04285a")}, null, Shader.TileMode.CLAMP);

        devicetext.getPaint().setShader(textShader1);


        // SharedPreferences initialization
        SharedPreferences sharedPreferences = getSharedPreferences("espValue", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

// Load saved preferences on activity start
        boolean isEsp64Selected = sharedPreferences.getBoolean("esp64Selected", true);
        boolean isKernelMode = sharedPreferences.getBoolean("kernelSelected", false);
        boolean isEspSafe = sharedPreferences.getBoolean("espSafe", true);


        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(R.attr.black, typedValue, true);
        int blackColor = typedValue.data; // Extract resolved color

        int mainColor = ContextCompat.getColor(this, R.color.main);

// ESP Selection
        if (isEsp64Selected) {
            esp64Button.setTextColor(mainColor);
            esp64Button.setIconTint(ColorStateList.valueOf(mainColor));
            esp32Button.setTextColor(blackColor);
            esp32Button.setIconTint(ColorStateList.valueOf(blackColor));
        } else {
            esp32Button.setTextColor(mainColor);
            esp32Button.setIconTint(ColorStateList.valueOf(mainColor));
            esp64Button.setTextColor(blackColor);
            esp64Button.setIconTint(ColorStateList.valueOf(blackColor));
        }

// Kernel Selection
        if (!isKernelMode) {
            systemModeBtn.setTextColor(mainColor);
            systemModeBtn.setIconTint(ColorStateList.valueOf(mainColor));
            kernelModeBtn.setTextColor(blackColor);
            kernelModeBtn.setIconTint(ColorStateList.valueOf(blackColor));
        } else {
            kernelModeBtn.setTextColor(mainColor);
            kernelModeBtn.setIconTint(ColorStateList.valueOf(mainColor));
            systemModeBtn.setTextColor(blackColor);
            systemModeBtn.setIconTint(ColorStateList.valueOf(blackColor));
        }

// ESP Safe Mode
        if (isEspSafe) {
            espsafe.setTextColor(mainColor);
            espsafe.setIconTint(ColorStateList.valueOf(mainColor));
            espunsafe.setTextColor(blackColor);
            espunsafe.setIconTint(ColorStateList.valueOf(blackColor));
        } else {
            espunsafe.setTextColor(mainColor);
            espunsafe.setIconTint(ColorStateList.valueOf(mainColor));
            espsafe.setTextColor(blackColor);
            espsafe.setIconTint(ColorStateList.valueOf(blackColor));
        }

// Click Listeners (Fixed setIconTint issue)
        esp64Button.setOnClickListener(v -> {
            bitversi = 64;
            esp64Button.setTextColor(mainColor);
            esp64Button.setIconTint(ColorStateList.valueOf(mainColor));
            esp32Button.setTextColor(blackColor);
            esp32Button.setIconTint(ColorStateList.valueOf(blackColor));
            editor.putBoolean("esp64Selected", true).apply();
        });

        esp32Button.setOnClickListener(v -> {
            bitversi = 32;
            esp32Button.setTextColor(mainColor);
            esp32Button.setIconTint(ColorStateList.valueOf(mainColor));
            esp64Button.setTextColor(blackColor);
            esp64Button.setIconTint(ColorStateList.valueOf(blackColor));
            editor.putBoolean("esp64Selected", false).apply();
        });

        systemModeBtn.setOnClickListener(view -> {
            kernel = false;
            systemModeBtn.setTextColor(mainColor);
            systemModeBtn.setIconTint(ColorStateList.valueOf(mainColor));
            kernelModeBtn.setTextColor(blackColor);
            kernelModeBtn.setIconTint(ColorStateList.valueOf(blackColor));
            editor.putBoolean("kernelSelected", false).apply();
        });

        kernelModeBtn.setOnClickListener(view -> {
            kernel = true;
            kernelModeBtn.setTextColor(mainColor);
            kernelModeBtn.setIconTint(ColorStateList.valueOf(mainColor));
            systemModeBtn.setTextColor(blackColor);
            systemModeBtn.setIconTint(ColorStateList.valueOf(blackColor));
            editor.putBoolean("kernelSelected", true).apply();
        });

        espsafe.setOnClickListener(v -> {
            espsafe.setTextColor(mainColor);
            espsafe.setIconTint(ColorStateList.valueOf(mainColor));
            espunsafe.setTextColor(blackColor);
            espunsafe.setIconTint(ColorStateList.valueOf(blackColor));
            editor.putBoolean("espSafe", true).apply();
        });

        espunsafe.setOnClickListener(v -> {
            espunsafe.setTextColor(mainColor);
            espunsafe.setIconTint(ColorStateList.valueOf(mainColor));
            espsafe.setTextColor(blackColor);
            espsafe.setIconTint(ColorStateList.valueOf(blackColor));
            editor.putBoolean("espSafe", false).apply();
        });


        TextView keylicence = findViewById(R.id.keylicence);
        ImageView eyeButton = findViewById(R.id.eye_button);

        String fullKey = PASSKEY + ":" + USERKEY;
        keylicence.setText(fullKey);

// By Default Blur Text
        keylicence.setTransformationMethod(new android.text.method.PasswordTransformationMethod());

        eyeButton.setOnClickListener(new View.OnClickListener() {
            boolean isVisible = false; // Track Visibility

            @Override
            public void onClick(View v) {
                if (isVisible) {
                    // Apply Blur (Hide Text)
                    keylicence.setTransformationMethod(new android.text.method.PasswordTransformationMethod());
                    eyeButton.setImageResource(R.drawable.ic_eye_off); // Change Icon
                } else {
                    // Remove Blur (Show Text)
                    keylicence.setTransformationMethod(null);
                    eyeButton.setImageResource(R.drawable.ic_eye); // Change Icon
                }
                isVisible = !isVisible; // Toggle State
            }
        });


    }


    @SuppressLint("ResourceAsColor")
    void initMenu2() {


        TextView deviceInfoTextView = findViewById(R.id.deviceInfoTextView);

// Get manufacturer, model, and Android version
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        String androidVersion = Build.VERSION.RELEASE;

// Combine the information into a single string
        String deviceInfo = manufacturer + " - Android " + androidVersion;

// Set the text to the TextView
        deviceInfoTextView.setText(deviceInfo);


        MaterialButton play = findViewById(R.id.play);
        boolean[] isPlaying = {false};

        play.setOnClickListener(v -> {
            if (!isPlaying[0]) {
                play.setIcon(getResources().getDrawable(R.drawable.pause));
                play.setText("PAUSE");
                play.setIconTint(getResources().getColorStateList(R.color.blazered));
                play.setTextColor(getResources().getColor(R.color.blazered));
                startPatcher();
                isPlaying[0] = true;
            } else {
                play.setIcon(getResources().getDrawable(R.drawable.play));
                play.setText("PLAY");
                play.setIconTint(getResources().getColorStateList(R.color.green));
                play.setTextColor(getResources().getColor(R.color.green));
                stopPatcher();
                isPlaying[0] = false;
            }
        });


        MaterialButton InstallTwitterBtn = findViewById(R.id.InstallTwitter);

        InstallTwitterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                LayoutInflater inflater = getLayoutInflater();
                View titleView = inflater.inflate(R.layout.custom_dialog_title, null);
                TextView titleText = titleView.findViewById(R.id.dialogTitle);
                titleText.setText(R.string.select_an_option);
                titleText.setTextColor(getResources().getColor(R.color.blazered));

                builder.setCustomTitle(titleView);

                boolean isAppRunning = isRunning("com.twitter.android");
                String[] options;
                if (isAppRunning) {
                    options = new String[]{getString(R.string.launch), getString(R.string.installed_), getString(R.string.uninstall_)};
                } else {
                    options = new String[]{getString(R.string.launch), getString(R.string.install), getString(R.string.uninstall_)};
                }

                builder.setAdapter(new android.widget.ArrayAdapter<String>(MainActivity.this, R.layout.dialog_item, options) {
                    @Override
                    public View getView(int position, View convertView, android.view.ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);
                        TextView optionText = view.findViewById(R.id.dialog_option_text);
                        optionText.setText(options[position]);
                        optionText.setTextColor(getResources().getColor(R.color.black));
                        return view;
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                // doShowProgress(true);
                                launchApk("com.twitter.android");

                                break;
                            case 1:
                                doShowProgress(true);
                                installResult = blackboxCore.installPackageAsUser(appPackage[3], 0);
                                if (installResult.success) {
                                    Toast.makeText(getApplicationContext(), R.string.install_success, Toast.LENGTH_LONG).show();

                                } else {
                                    Toast.makeText(getApplicationContext(), R.string.install_failed, Toast.LENGTH_LONG).show();

                                }
                                break;
                            case 2:
                                doShowProgress(true);
                                unInstallWithDellay("com.twitter.android");

                                break;
                        }
                    }
                });

                AlertDialog dialog = builder.create();

                ShapeDrawable background = new ShapeDrawable();
                float cornerRadius = 4f * getResources().getDisplayMetrics().density;
                background.setShape(new RoundRectShape(new float[]{cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius}, null, null));
                background.getPaint().setColor(Color.WHITE);

                dialog.setOnShowListener(dialogInterface -> {
                    if (dialog.getWindow() != null) {
                        dialog.getWindow().setBackgroundDrawable(background);
                    }
                });

                dialog.show();
            }
        });

        MaterialButton installFbButton = findViewById(R.id.InstallFb);

        installFbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                LayoutInflater inflater = getLayoutInflater();
                View titleView = inflater.inflate(R.layout.custom_dialog_title, null);
                TextView titleText = titleView.findViewById(R.id.dialogTitle);
                titleText.setText(R.string.select_an_option);
                titleText.setTextColor(getResources().getColor(R.color.blazered));

                builder.setCustomTitle(titleView);

                boolean isAppRunning = isRunning("mark.via.gp");
                String[] options;
                if (isAppRunning) {
                    options = new String[]{getString(R.string.launch), getString(R.string.installed_), getString(R.string.uninstall_)};
                } else {
                    options = new String[]{getString(R.string.launch), getString(R.string.install), getString(R.string.uninstall_)};
                }

                builder.setAdapter(new android.widget.ArrayAdapter<String>(MainActivity.this, R.layout.dialog_item, options) {
                    @Override
                    public View getView(int position, View convertView, android.view.ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);
                        TextView optionText = view.findViewById(R.id.dialog_option_text);
                        optionText.setText(options[position]);
                        optionText.setTextColor(getResources().getColor(R.color.black));
                        return view;
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                // doShowProgress(true);
                                // launchApk(packageName);
                                launchApk("mark.via.gp");
                                break;
                            case 1:
                                doShowProgress(true);
                                installResult = blackboxCore.installPackageAsUser(appPackage[7], 0);
                                if (installResult.success) {
                                    Toast.makeText(getApplicationContext(), R.string.install_success, Toast.LENGTH_LONG).show();

                                } else {
                                    Toast.makeText(getApplicationContext(), R.string.install_failed, Toast.LENGTH_LONG).show();

                                }
                                break;
                            case 2:
                                doShowProgress(true);
                                unInstallWithDellay("mark.via.gp");

                                break;
                        }
                    }
                });

                AlertDialog dialog = builder.create();

                ShapeDrawable background = new ShapeDrawable();
                float cornerRadius = 4f * getResources().getDisplayMetrics().density;
                background.setShape(new RoundRectShape(new float[]{cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius}, null, null));
                background.getPaint().setColor(Color.WHITE);

                dialog.setOnShowListener(dialogInterface -> {
                    if (dialog.getWindow() != null) {
                        dialog.getWindow().setBackgroundDrawable(background);
                    }
                });

                dialog.show();
            }
        });

 

        AppCompatButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
        TextView vrIndia = findViewById(R.id.vrindia);
        String packageName = "com.pubg.imobile";

        boolean isAppInstalledOnDevice = isAppInstalled(packageName);
        boolean isAppInstalledInBlackbox = blackboxCore.isInstalled(packageName, 0);


        if (isAppInstalledInBlackbox) {
            vrIndia.setText(R.string.installed_available);
        } else if (isAppInstalledOnDevice) {
            vrIndia.setText(R.string.not_installed_available);
        } else {
            vrIndia.setText(R.string.not_installed_unavailable);
        }


        final boolean[] isAppRunning = {isRunning(packageName)};
InstallBgmiBtn.setText(isAppRunning[0] ? getString(R.string.launch) : getString(R.string.install));

InstallBgmiBtn.setOnClickListener(v -> {
    gameint = 5;

 
    if (vrIndia.getText().toString().equals(getString(R.string.not_installed_unavailable))) {
        Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.game_not_available), Toast.LENGTH_LONG).show();
        return;
    }

    if (InstallBgmiBtn.getText().toString().equals(getString(R.string.launch))) {
   
        LayoutInflater inflater = LayoutInflater.from(InstallBgmiBtn.getContext());
        View viewLottie = inflater.inflate(R.layout.animation_lottie, null);
        AlertDialog dialogLottie = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewLottie)
                .setCancelable(false)
                .create();
        if (dialogLottie.getWindow() != null) {
            dialogLottie.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        LottieAnimationView lottieView = viewLottie.findViewById(R.id.lottie_animation);
        lottieView.setAnimation(R.raw.rocket);
        lottieView.playAnimation();
        dialogLottie.show();

        blackboxCore.launchApk("com.pubg.imobile", 0);
        launchbypassNoRoot();
        startPatcher();

    } else {
     
        LayoutInflater inflater = LayoutInflater.from(InstallBgmiBtn.getContext());
        View viewloading = inflater.inflate(R.layout.animation_launch, null);
        AlertDialog dialogloading = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewloading)
                .setCancelable(false)
                .create();
        if (dialogloading.getWindow() != null) {
            dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialogloading.show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            installResult = blackboxCore.installPackageAsUser(packageName, 0);
            if (installResult.success) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.install_success), Toast.LENGTH_LONG).show();
                InstallBgmiBtn.setText(getString(R.string.launch));
                vrIndia.setText(R.string.installed_available);
            } else {
                Toast.makeText(this, installResult.msg, Toast.LENGTH_SHORT).show();
            }
            doShowProgress(true);

            File obbFolder = new File("/storage/emulated/0/SdCard/Android/obb/" + packageName);
            File[] obbFiles = obbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageName + "\\.obb"));

            if (obbFiles != null && obbFiles.length > 0) {
                Toast.makeText(getApplicationContext(), "OBB Installed", Toast.LENGTH_LONG).show();
            } else {
                File sourceFolder = new File("/storage/emulated/0/Android/obb/" + packageName);
                File[] sourceFiles = sourceFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageName + "\\.obb"));

                if (sourceFiles != null && sourceFiles.length > 0) {
                    new MyCopyTask().execute(sourceFiles[0].getAbsolutePath(), packageName);
                }
            }

            if (dialogloading.isShowing()) dialogloading.dismiss();
        }, 2000);
    }
});
        
        
        
        
        


        InstallBgmiBtn.setOnLongClickListener(v -> {
            showBottomSheetDialogUninstall(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.do_you_want_to_uninstall_this_app), false, v1 -> {
                unInstallWithDellay(packageName);
                InstallBgmiBtn.setText(getString(R.string.install));

                boolean isStillInstalledOnDevice = isAppInstalled(packageName);
                boolean isStillInstalledInBlackbox = blackboxCore.isInstalled(packageName, 0);

                if (isStillInstalledInBlackbox) {
                    vrIndia.setText(R.string.installed_available);
                } else if (isStillInstalledOnDevice) {
                    vrIndia.setText(R.string.not_installed_available);
                } else {
                    vrIndia.setText(R.string.not_installed_unavailable);
                }

                dismissBottomSheetDialog();
            });
            return true;
        });



        AppCompatButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
        TextView vrGlobal = findViewById(R.id.vrglobal);
        String packageNameGl = "com.tencent.ig";

        boolean isGlobalInstalledOnDevice = isGlobalInstalled(packageNameGl);
        boolean isGlobalInstalledInBlackbox = blackboxCore.isInstalled(packageNameGl, 0);


        if (isGlobalInstalledInBlackbox) {
            vrGlobal.setText(R.string.installed_available);
        } else if (isGlobalInstalledOnDevice) {
            vrGlobal.setText(R.string.not_installed_available);
        } else {
            vrGlobal.setText(R.string.not_installed_unavailable);
        }

// App Running Status Check
        final boolean[] isGlobalRunning = {isRunning(packageNameGl)};
InstallGlobalBtn.setText(isGlobalRunning[0] ? getString(R.string.launch) : getString(R.string.install));

InstallGlobalBtn.setOnClickListener(v -> {
    gameint = 1;


    if (vrGlobal.getText().toString().equals(getString(R.string.not_installed_unavailable))) {
        Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.game_not_available), Toast.LENGTH_LONG).show();
        return;
    }

    if (InstallGlobalBtn.getText().toString().equals(getString(R.string.launch))) {
     
        LayoutInflater inflater = LayoutInflater.from(InstallGlobalBtn.getContext());
        View viewLottie = inflater.inflate(R.layout.animation_lottie, null);
        AlertDialog dialogLottie = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewLottie)
                .setCancelable(false)
                .create();
        if (dialogLottie.getWindow() != null) {
            dialogLottie.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        LottieAnimationView lottieView = viewLottie.findViewById(R.id.lottie_animation);
        lottieView.setAnimation(R.raw.rocket);
        lottieView.playAnimation();
        dialogLottie.show();

        blackboxCore.launchApk("com.tencent.ig", 0);
        launchbypassNoRoot();
        startPatcher();
    } else {
    
        LayoutInflater inflater = LayoutInflater.from(InstallGlobalBtn.getContext());
        View viewloading = inflater.inflate(R.layout.animation_launch, null);
        AlertDialog dialogloading = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewloading)
                .setCancelable(false)
                .create();
        if (dialogloading.getWindow() != null) {
            dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialogloading.show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            installResult = blackboxCore.installPackageAsUser(packageNameGl, 0);
            if (installResult.success) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.install_success), Toast.LENGTH_LONG).show();
                InstallGlobalBtn.setText(getString(R.string.launch));
                vrGlobal.setText(R.string.installed_available);
            } else {
                Toast.makeText(this, installResult.msg, Toast.LENGTH_SHORT).show();
            }
            doShowProgress(true);

            File obbFolder = new File("/storage/emulated/0/SdCard/Android/obb/" + packageNameGl);
            File[] obbFiles = obbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameGl + "\\.obb"));

            if (obbFiles != null && obbFiles.length > 0) {
                Toast.makeText(getApplicationContext(), "OBB Installed", Toast.LENGTH_LONG).show();
            } else {
                File sourceFolder = new File("/storage/emulated/0/Android/obb/" + packageNameGl);
                File[] sourceFiles = sourceFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameGl + "\\.obb"));

                if (sourceFiles != null && sourceFiles.length > 0) {
                    new MyCopyTask().execute(sourceFiles[0].getAbsolutePath(), packageNameGl);
                }
            }

            if (dialogloading.isShowing()) dialogloading.dismiss();
        }, 2000);
    }
});
        
        
        
        
        
        
        


        InstallGlobalBtn.setOnLongClickListener(v -> {
            showBottomSheetDialogUninstall(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.do_you_want_to_uninstall_this_app), false, v1 -> {
                unInstallWithDellay(packageNameGl);
                InstallGlobalBtn.setText(getString(R.string.install));

                boolean isStillInstalledOnDevice = isGlobalInstalled(packageNameGl);
                boolean isStillInstalledInBlackbox = blackboxCore.isInstalled(packageNameGl, 0);

                if (isStillInstalledInBlackbox) {
                    vrGlobal.setText(R.string.installed_available);
                } else if (isStillInstalledOnDevice) {
                    vrGlobal.setText(R.string.not_installed_available);
                } else {
                    vrGlobal.setText(R.string.not_installed_unavailable);
                }

                dismissBottomSheetDialog();
            });
            return true;
        });



        AppCompatButton InstallKoreaBtn = findViewById(R.id.InstallKR);
        TextView vrKorea = findViewById(R.id.vrkr);
        String packageNameKr = "com.pubg.krmobile";

        boolean isKoreaInstalledOnDevice = isKoreaInstalled(packageNameKr);
        boolean isKoreaInstalledInBlackbox = blackboxCore.isInstalled(packageNameKr, 0);


        if (isKoreaInstalledInBlackbox) {
            vrKorea.setText(R.string.installed_available);
        } else if (isKoreaInstalledOnDevice) {
            vrKorea.setText(R.string.not_installed_available);
        } else {
            vrKorea.setText(R.string.not_installed_unavailable);
        }


        final boolean[] isKoreaRunning = {isRunning(packageNameKr)};
InstallKoreaBtn.setText(isKoreaRunning[0] ? getString(R.string.launch) : getString(R.string.install));

InstallKoreaBtn.setOnClickListener(v -> {
    gameint = 2;

    if (vrKorea.getText().toString().equals(getString(R.string.not_installed_unavailable))) {
        Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.game_not_available), Toast.LENGTH_LONG).show();
        return;
    }

    if (InstallKoreaBtn.getText().toString().equals(getString(R.string.launch))) {
    
        LayoutInflater inflater = LayoutInflater.from(InstallKoreaBtn.getContext());
        View viewLottie = inflater.inflate(R.layout.animation_lottie, null);
        AlertDialog dialogLottie = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewLottie)
                .setCancelable(false)
                .create();
        if (dialogLottie.getWindow() != null) {
            dialogLottie.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        LottieAnimationView lottieView = viewLottie.findViewById(R.id.lottie_animation);
        lottieView.setAnimation(R.raw.rocket);
        lottieView.playAnimation();
        dialogLottie.show();

        blackboxCore.launchApk("com.pubg.krmobile", 0);
        launchbypassNoRoot();
        startPatcher();
    } else {
    
        LayoutInflater inflater = LayoutInflater.from(InstallKoreaBtn.getContext());
        View viewloading = inflater.inflate(R.layout.animation_launch, null);
        AlertDialog dialogloading = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewloading)
                .setCancelable(false)
                .create();
        if (dialogloading.getWindow() != null) {
            dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialogloading.show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            installResult = blackboxCore.installPackageAsUser(packageNameKr, 0);
            if (installResult.success) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.install_success), Toast.LENGTH_LONG).show();
                InstallKoreaBtn.setText(getString(R.string.launch));
                vrKorea.setText(R.string.installed_available);
            } else {
                Toast.makeText(this, installResult.msg, Toast.LENGTH_SHORT).show();
            }
            doShowProgress(true);

            File obbFolder = new File("/storage/emulated/0/SdCard/Android/obb/" + packageNameKr);
            File[] obbFiles = obbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameKr + "\\.obb"));

            if (obbFiles != null && obbFiles.length > 0) {
                Toast.makeText(getApplicationContext(), "OBB Installed", Toast.LENGTH_LONG).show();
            } else {
                File sourceFolder = new File("/storage/emulated/0/Android/obb/" + packageNameKr);
                File[] sourceFiles = sourceFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameKr + "\\.obb"));

                if (sourceFiles != null && sourceFiles.length > 0) {
                    new MyCopyTask().execute(sourceFiles[0].getAbsolutePath(), packageNameKr);
                }
            }

            if (dialogloading.isShowing()) dialogloading.dismiss();
        }, 2000);
    }
});
        
        
        
        
        
        
        
        


        InstallKoreaBtn.setOnLongClickListener(v -> {
            showBottomSheetDialogUninstall(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.do_you_want_to_uninstall_this_app), false, v1 -> {
                unInstallWithDellay(packageNameKr);
                InstallKoreaBtn.setText(getString(R.string.install));

                boolean isStillInstalledOnDevice = isKoreaInstalled(packageNameKr);
                boolean isStillInstalledInBlackbox = blackboxCore.isInstalled(packageNameKr, 0);

                if (isStillInstalledInBlackbox) {
                    vrKorea.setText(R.string.installed_available);
                } else if (isStillInstalledOnDevice) {
                    vrKorea.setText(R.string.not_installed_available);
                } else {
                    vrKorea.setText(R.string.not_installed_unavailable);
                }

                dismissBottomSheetDialog();
            });
            return true;
        });



        AppCompatButton InstallVNGBtn = findViewById(R.id.InstallVNG);
        TextView vrVNG = findViewById(R.id.vrvng);
        String packageNameVng = "com.vng.pubgmobile";

        boolean isVNGInstalledOnDevice = isVNGInstalled(packageNameVng);
        boolean isVNGInstalledInBlackbox = blackboxCore.isInstalled(packageNameVng, 0);


        if (isVNGInstalledInBlackbox) {
            vrVNG.setText(R.string.installed_available);
        } else if (isVNGInstalledOnDevice) {
            vrVNG.setText(R.string.not_installed_available);
        } else {
            vrVNG.setText(R.string.not_installed_unavailable);
        }

// App Running Status Check
        final boolean[] isVNGRunning = {isRunning(packageNameVng)};
InstallVNGBtn.setText(isVNGRunning[0] ? getString(R.string.launch) : getString(R.string.install));

InstallVNGBtn.setOnClickListener(v -> {
    gameint = 3;


    if (vrVNG.getText().toString().equals(getString(R.string.not_installed_unavailable))) {
        Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.game_not_available), Toast.LENGTH_LONG).show();
        return;
    }

    if (InstallVNGBtn.getText().toString().equals(getString(R.string.launch))) {
    
        LayoutInflater inflater = LayoutInflater.from(InstallVNGBtn.getContext());
        View viewLottie = inflater.inflate(R.layout.animation_lottie, null);
        AlertDialog dialogLottie = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewLottie)
                .setCancelable(false)
                .create();
        if (dialogLottie.getWindow() != null) {
            dialogLottie.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        LottieAnimationView lottieView = viewLottie.findViewById(R.id.lottie_animation);
        lottieView.setAnimation(R.raw.rocket);
        lottieView.playAnimation();
        dialogLottie.show();

        blackboxCore.launchApk("com.vng.pubgmobile", 0);
        launchbypassNoRoot();
        startPatcher();
    } else {
   
        LayoutInflater inflater = LayoutInflater.from(InstallVNGBtn.getContext());
        View viewloading = inflater.inflate(R.layout.animation_launch, null);
        AlertDialog dialogloading = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewloading)
                .setCancelable(false)
                .create();
        if (dialogloading.getWindow() != null) {
            dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialogloading.show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            installResult = blackboxCore.installPackageAsUser(packageNameVng, 0);
            if (installResult.success) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.install_success), Toast.LENGTH_LONG).show();
                InstallVNGBtn.setText(getString(R.string.launch));
                vrVNG.setText(R.string.installed_available);
            } else {
                Toast.makeText(this, installResult.msg, Toast.LENGTH_SHORT).show();
            }
            doShowProgress(true);

            File obbFolder = new File("/storage/emulated/0/SdCard/Android/obb/" + packageNameVng);
            File[] obbFiles = obbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameVng + "\\.obb"));

            if (obbFiles != null && obbFiles.length > 0) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.obb_copied), Toast.LENGTH_LONG).show();
            } else {
                File sourceFolder = new File("/storage/emulated/0/Android/obb/" + packageNameVng);
                File[] sourceFiles = sourceFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameVng + "\\.obb"));

                if (sourceFiles != null && sourceFiles.length > 0) {
                    new MyCopyTask().execute(sourceFiles[0].getAbsolutePath(), packageNameVng);
                }
            }

            if (dialogloading.isShowing()) dialogloading.dismiss();
        }, 2000);
    }
});









        InstallVNGBtn.setOnLongClickListener(v -> {
            showBottomSheetDialogUninstall(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.do_you_want_to_uninstall_this_app), false, v1 -> {
                unInstallWithDellay(packageNameVng);
                InstallVNGBtn.setText(getString(R.string.install));

                boolean isStillInstalledOnDevice = isVNGInstalled(packageNameVng);
                boolean isStillInstalledInBlackbox = blackboxCore.isInstalled(packageNameVng, 0);

                if (isStillInstalledInBlackbox) {
                    vrVNG.setText(R.string.installed_available);
                } else if (isStillInstalledOnDevice) {
                    vrVNG.setText(R.string.not_installed_available);
                } else {
                    vrVNG.setText(R.string.not_installed_unavailable);
                }

                dismissBottomSheetDialog();
            });
            return true;
        });


        AppCompatButton InstallTWBtn = findViewById(R.id.InstallTW);
        TextView vrTW = findViewById(R.id.vrtw);
        String packageNameTW = "com.rekoo.pubgm";

        boolean isTWInstalledOnDevice = isTWInstalled(packageNameTW);
        boolean isTWInstalledInBlackbox = blackboxCore.isInstalled(packageNameTW, 0);

// Install Status Update
        if (isTWInstalledInBlackbox) {
            vrTW.setText(R.string.installed_available);
        } else if (isTWInstalledOnDevice) {
            vrTW.setText(R.string.not_installed_available);
        } else {
            vrTW.setText(R.string.not_installed_unavailable);
        }

// App Running Status Check
        final boolean[] isTWRunning = {isRunning(packageNameTW)};
InstallTWBtn.setText(isTWRunning[0] ? getString(R.string.launch) : getString(R.string.install));

InstallTWBtn.setOnClickListener(v -> {
    gameint = 4;


    if (vrTW.getText().toString().equals(getString(R.string.not_installed_unavailable))) {
        Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.game_not_available), Toast.LENGTH_LONG).show();
        return;
    }

    if (InstallTWBtn.getText().toString().equals(getString(R.string.launch))) {
     
        LayoutInflater inflater = LayoutInflater.from(InstallTWBtn.getContext());
        View viewLottie = inflater.inflate(R.layout.animation_lottie, null);
        AlertDialog dialogLottie = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewLottie)
                .setCancelable(false)
                .create();
        if (dialogLottie.getWindow() != null) {
            dialogLottie.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        LottieAnimationView lottieView = viewLottie.findViewById(R.id.lottie_animation);
        lottieView.setAnimation(R.raw.rocket);
        lottieView.playAnimation();
        dialogLottie.show();

        blackboxCore.launchApk("com.rekoo.pubgm", 0);
        launchbypassNoRoot();
        startPatcher();
    } else {
     
        LayoutInflater inflater = LayoutInflater.from(InstallTWBtn.getContext());
        View viewloading = inflater.inflate(R.layout.animation_launch, null);
        AlertDialog dialogloading = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
                .setView(viewloading)
                .setCancelable(false)
                .create();
        if (dialogloading.getWindow() != null) {
            dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialogloading.show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            installResult = blackboxCore.installPackageAsUser(packageNameTW, 0);
            if (installResult.success) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.install_success), Toast.LENGTH_LONG).show();
                InstallTWBtn.setText(getString(R.string.launch));
                vrTW.setText(R.string.installed_available);
            } else {
                Toast.makeText(this, installResult.msg, Toast.LENGTH_SHORT).show();
            }
            doShowProgress(true);

            File obbFolder = new File("/storage/emulated/0/SdCard/Android/obb/" + packageNameTW);
            File[] obbFiles = obbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameTW + "\\.obb"));

            if (obbFiles != null && obbFiles.length > 0) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.obb_copied), Toast.LENGTH_LONG).show();
            } else {
                File sourceFolder = new File("/storage/emulated/0/Android/obb/" + packageNameTW);
                File[] sourceFiles = sourceFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + packageNameTW + "\\.obb"));

                if (sourceFiles != null && sourceFiles.length > 0) {
                    new MyCopyTask().execute(sourceFiles[0].getAbsolutePath(), packageNameTW);
                }
            }

            if (dialogloading.isShowing()) dialogloading.dismiss();
        }, 2000);
    }
});
        
        
        
        
        
        

// Long Click Listener for Uninstall
        InstallTWBtn.setOnLongClickListener(v -> {
            showBottomSheetDialogUninstall(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.do_you_want_to_uninstall_this_app), false, v1 -> {
                unInstallWithDellay(packageNameTW);
                InstallTWBtn.setText(getString(R.string.install));

                boolean isStillInstalledOnDevice = isTWInstalled(packageNameTW);
                boolean isStillInstalledInBlackbox = blackboxCore.isInstalled(packageNameTW, 0);

                if (isStillInstalledInBlackbox) {
                    vrTW.setText(R.string.installed_available);
                } else if (isStillInstalledOnDevice) {
                    vrTW.setText(R.string.not_installed_available);
                } else {
                    vrTW.setText(R.string.not_installed_unavailable);
                }

                dismissBottomSheetDialog();
            });
            return true;
        });


        SharedPreferences sharedPreferences = getSharedPreferences("espValue", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int savedHideRecord = sharedPreferences.getInt("hiderecord", 0);
        MaterialButton hideRecordButton = findViewById(R.id.hiderecord);

// Set initial UI based on saved preference
        if (savedHideRecord == 1) {
            //hideRecordButton.setTextColor(getResources().getColor(R.color.white));
            hideRecordButton.setIconTintResource(R.color.green);
        } else {
            //hideRecordButton.setTextColor(getResources().getColor(R.color.white));
            hideRecordButton.setIconTintResource(R.color.blazered);
        }

        findViewById(R.id.hiderecord).setOnClickListener(v -> {
            if (Sufii) {
                showBottomSheetDialog(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.did_you_want_hide), false, sv -> {
                    hiderecord = 1;
                    //hideRecordButton.setTextColor(getResources().getColor(R.color.white));
                    hideRecordButton.setIconTintResource(R.color.green);
                    editor.putInt("hiderecord", 1).apply(); // Save hiderecord as 1
                    dismissBottomSheetDialog();
                }, v1 -> {
                    hiderecord = 0;
                    //hideRecordButton.setTextColor(getResources().getColor(R.color.white));
                    hideRecordButton.setIconTintResource(R.color.blazered);
                    editor.putInt("hiderecord", 0).apply(); // Save hiderecord as 0
                    dismissBottomSheetDialog();
                });
            } else {
                // toastImage(R.drawable.notife, String.valueOf((R.string.please_upgrade_to_premium_)));
            }
        });


        findViewById(R.id.fixinstall).setOnClickListener(v -> {
            if (Sufii) {
                showBottomSheetDialog(getResources().getDrawable(R.drawable.icon_toast_alert), getString(R.string.confirm), getString(R.string.this_for_fix_obb_not_found_need_actived_this), false, sv -> {
                    fixinstallint = true;
                    //String pkg;
                    if (gameint == 1) {
                        pkg = "com.tencent.ig";
                    } else if (gameint == 2) {
                        pkg = "com.pubg.krmobile";
                    } else if (gameint == 3) {
                        pkg = "com.vng.pubgmobile";
                    } else if (gameint == 4) {
                        pkg = "com.rekoo.pubgm";
                    } else if (gameint == 5) {
                        pkg = "com.pubg.imobile";
                    } else if (gameint == 0) {
                        Toast.makeText(this, R.string.first_select_game_please, Toast.LENGTH_SHORT).show();
                    }

                    Intent i = new Intent();
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    i.setAction(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    Uri muri = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid/document/primary%3AAndroid%2Fobb%2F" + pkg);
                    i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, muri);
                    startActivityForResult(i, 0);

                    dismissBottomSheetDialog();
                }, v1 -> {
                    fixinstallint = false;
                    dismissBottomSheetDialog();
                });
            } else {
                //toastImage(R.drawable.notife, String.valueOf(R.string.please_upgrade_to_premium_));
            }
        });


    }





    public void SettingESP() {
    // Request Storage + Mic Permissions

    sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

    findViewById(R.id.savesetting).setOnClickListener(v -> {
        try {
            importSharedPreferences();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, R.string.failed_to_import, Toast.LENGTH_SHORT).show();
        }
    });

    findViewById(R.id.exportsetting).setOnClickListener(v -> {
   
            Toast.makeText(MainActivity.this, R.string.failed_to_export, Toast.LENGTH_SHORT).show();
        
    });

    findViewById(R.id.resetsetting).setOnClickListener(v -> {
        resetSharedPreferences();
        Toast.makeText(MainActivity.this, R.string.success_reset, Toast.LENGTH_SHORT).show();
    });
}

    private void importSharedPreferences() throws IOException {
        File srcFile = new File(Environment.getExternalStorageDirectory(), PREF_NAME + ".xml");
        File dstFile = new File(getApplication().getDataDir().toString() + "/shared_prefs/" + PREF_NAME + ".xml");

        if (srcFile.exists()) {
            FileChannel src = null;
            FileChannel dst = null;
            try {
                src = new FileInputStream(srcFile).getChannel();
                dst = new FileOutputStream(dstFile).getChannel();
                dst.transferFrom(src, 0, src.size());
                Toast.makeText(MainActivity.this, getString(R.string.imported_from) + srcFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            } finally {
                if (src != null) {
                    src.close();
                }
                if (dst != null) {
                    dst.close();
                }
            }
        } else {
            Toast.makeText(MainActivity.this, R.string.setting_esp_file_not_found, Toast.LENGTH_SHORT).show();
        }
    }

    private void resetSharedPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    void gameversion(LinearLayout a, LinearLayout b, LinearLayout c, LinearLayout d, LinearLayout e) {
        a.setBackgroundResource(R.drawable.bgfituron);
        b.setBackgroundResource(R.drawable.bgfituroff);
        c.setBackgroundResource(R.drawable.bgfituroff);
        d.setBackgroundResource(R.drawable.bgfituroff);
        e.setBackgroundResource(R.drawable.bgfituroff);
    }


    void init() {
        //Animation animation = AnimationUtils.loadAnimation(this, R.anim.bounce);
        LinearLayout navhome = findViewById(R.id.navhome);
        LinearLayout navsetting = findViewById(R.id.navsetting);
        LinearLayout effecthome = findViewById(R.id.effecthome);
        LinearLayout effectsetting = findViewById(R.id.effectsetting);
        LinearLayout menu1 = findViewById(R.id.imenu1);
        LinearLayout menu2 = findViewById(R.id.imenu2);
        ImageView home = findViewById(R.id.imghome);
        ImageView sett = findViewById(R.id.imgsett);
        TextView txtsett = findViewById(R.id.txtsett);
        TextView txthome = findViewById(R.id.txthome);
        //TextView headtext = findViewById(R.id.headtext);

        navhome.setOnClickListener(v -> {
            menu1.setVisibility(View.VISIBLE);
            menu2.setVisibility(View.GONE);
            //headtext.setText("Home");

            txthome.setTextColor(getResources().getColor(R.color.main));
            txtsett.setTextColor(getResources().getColor(R.color.gray));
            home.setBackgroundResource(R.drawable.ic_home);
            sett.setBackgroundResource(R.drawable.outline_settings_24);
        });

        navsetting.setOnClickListener(v -> {
            menu1.setVisibility(View.GONE);
            menu2.setVisibility(View.VISIBLE);
            //headtext.setText("Settings");


            txthome.setTextColor(getResources().getColor(R.color.gray));
            txtsett.setTextColor(getResources().getColor(R.color.main));
            home.setBackgroundResource(R.drawable.ic_home_outline);
            sett.setBackgroundResource(R.drawable.ic_helpon);
        });

    }


    void Makedir() {
        if (!Shell.rootAccess()) {
            File GlobalFolder = new File("/storage/emulated/0/SdCard/Android/obb/com.tencent.ig/");
            File KoreaFolder = new File("/storage/emulated/0/SdCard/Android/obb/com.pubg.krmobile/");
            File VietnamFolder = new File("/storage/emulated/0/SdCard/Android/obb/com.vng.pubgmobile/");
            File TaiwanFolder = new File("/storage/emulated/0/SdCard/Android/obb/com.rekoo.pubgm/");
            File BgmiFolder = new File("/storage/emulated/0/SdCard/Android/obb/com.pubg.imobile/");
            GlobalFolder.mkdirs();
            KoreaFolder.mkdirs();
            VietnamFolder.mkdirs();
            TaiwanFolder.mkdirs();
            BgmiFolder.mkdirs();
        }
    }



    public void addAdditionalApp(boolean system, String packageName) {
    Handler handler = new Handler(Looper.getMainLooper());
    handler.post(new Runnable() {
        @Override
        public void run() {
            if (isPackageInstalled(packageName)) {
                doShowProgress(true);
            } else {
                try {
                    installResult = blackboxCore.installPackageAsUser(packageName, 0);
                    if (installResult.success) {
                        doShowProgress(true);
                        Toast.makeText(MainActivity.this,
                                getString(R.string.apk_installed),
                                Toast.LENGTH_LONG).show();
                    }
                } catch (Exception err) {
                    FLog.error(err.getMessage());
                    doHideProgress();
                }
            }
        }
    });
}
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            String status = data.getStringExtra("STATUS");
            if (status != null) {
                statusText.setText("Installation Status: " + status);
            }
        }
    }

    public void launchApk(String packageName) {
    if (!isPackageInstalled(packageName)) {
        Toast.makeText(getApplicationContext(),
                getString(R.string.not_installed),
                Toast.LENGTH_LONG).show();
        return;
    }
    try {
        blackboxCore.launchApk(packageName, 0);
    } catch (Exception e) {
        throw new RuntimeException(e);
    }
}

    public void unInstallApp(String packageName) {
        BlackBoxCore.get().uninstallPackageAsUser(packageName, 0);

    }

    public boolean isRunning(String packageName) {

        return blackboxCore.isInstalled(packageName, 0);

    }

    public void stopRunningApp(String packageName) {

        BlackBoxCore.get().stopPackage(packageName, 0);
    }

    public ApplicationInfo getApplicationInfoContainer(String packageName) {
        if (!isPackageInstalled(packageName)) {
            Toast.makeText(getApplicationContext(), R.string.app_not_installed_please_install_first, Toast.LENGTH_LONG).show();
            return null;
        }

        ApplicationInfo applicationInfo = null;

        if (applicationInfo == null) {
            return null;
        }
        return applicationInfo;
    }

    boolean isPackageInstalled(String packageName) {
        return blackboxCore.isInstalled(packageName, 0);
    }



    private void unInstallWithDellay(String packageName) {
    unInstallApp(packageName);
    Toast.makeText(getApplicationContext(),
            getString(R.string.successfully_uninstalled),
            Toast.LENGTH_LONG).show();
}












private void restartApp() {
    Intent intent = getBaseContext().getPackageManager()
        .getLaunchIntentForPackage(getBaseContext().getPackageName());
    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
        Runtime.getRuntime().exit(0);
    }
}



    private void EnableCars() {
        SharedPreferences prefs = getSharedPreferences("espValue", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

       /* editor.putBoolean("BRDM", true);
        editor.putBoolean("UAZ", true);
        editor.putBoolean("Snowbike", true);
        editor.putBoolean("ATV1", true);
        editor.putBoolean("Mirado", true);
        editor.putBoolean("Dacia", true);
        editor.putBoolean("UTV", true);
        editor.putBoolean("Monster", true);
        editor.putBoolean("Motor Glider", true);
        editor.putBoolean("Buggy", true);
        editor.putBoolean("Bike", true);
        editor.putBoolean("CoupeRB", true);
        editor.putBoolean("Bus", true);
        editor.putBoolean("Truck", true);
        editor.putBoolean("Snowmobile", true);
        editor.putBoolean("LadaNiva", true);
        editor.putBoolean("Trike", true);
        editor.putBoolean("Scooter", true);
        editor.putBoolean("Tempo", true);
        editor.putBoolean("Jet", true);
        editor.putBoolean("Boat", true);
        editor.putBoolean("Rony", true);*/

        editor.apply(); // Save changes asynchronously
    }

    private void EnableItems() {
        SharedPreferences prefs = getSharedPreferences("espValue", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

       /* editor.putBoolean("6x", true);
        editor.putBoolean("5.56mm", true);
        editor.putBoolean("Grenade", true);
        editor.putBoolean("FirstAid", true);
        editor.putBoolean("Helmet L3", true);
        editor.putBoolean("3x", true);
        editor.putBoolean("MedKit", true);
        editor.putBoolean("Vest L3", true);
        editor.putBoolean("UMP", true);
        editor.putBoolean("Molotov", true);
        editor.putBoolean("Bag L3", true);
        editor.putBoolean("M416", true);
        editor.putBoolean("7.62mm", true);
        editor.putBoolean("AWM", true);
        editor.putBoolean("MG3", true);
        editor.putBoolean("AKM", true);
        editor.putBoolean("P90", true);
        editor.putBoolean("Groza", true);
        editor.putBoolean("LootBox", true);
        editor.putBoolean("Groza", true);
        editor.putBoolean("LootBox", true);

        // Bt Settings
        editor.putInt("Distances", 150);
        editor.putInt("getrangeAim", 200);*/

        editor.apply(); // Save changes asynchronously
    }


    private boolean isAppInstalled(String packageName) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private boolean isGlobalInstalled(String packageNameGl) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(packageNameGl, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private boolean isKoreaInstalled(String packageNameKr) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(packageNameKr, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private boolean isVNGInstalled(String packageNameVng) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(packageNameVng, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private boolean isTWInstalled(String packageNameTW) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(packageNameTW, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void displayRamUsage() {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        long totalMemory = memoryInfo.totalMem;
        long availableMemory = memoryInfo.availMem;
        long usedMemory = totalMemory - availableMemory;
        double percentageUsed = (double) usedMemory / totalMemory * 100;

        TextView ramTextView = findViewById(R.id.ramTextView);
        ProgressBar ramProgressBar = findViewById(R.id.storageProgressBar);
        TextView percentageTextView = findViewById(R.id.percentageText);

        if (ramTextView != null && ramProgressBar != null && percentageTextView != null) {
            ramTextView.setText(String.format(Locale.getDefault(), getString(R.string._2f_gb_used_2f_gb_available), usedMemory / (1024.0 * 1024.0 * 1024.0), availableMemory / (1024.0 * 1024.0 * 1024.0)));

            ramProgressBar.setProgress((int) percentageUsed);
            percentageTextView.setText(String.format(Locale.getDefault(), "%.0f%%", percentageUsed));
        }
    }


    private long getTotalMemory() {
        return Runtime.getRuntime().maxMemory();
    }

    private long getFreeMemory() {
        return Runtime.getRuntime().freeMemory();
    }

    private void displayStorageUsage() {
        try {
            StatFs stat = new StatFs(getFilesDir().getAbsolutePath());
            long totalBytes = stat.getTotalBytes();
            long freeBytes = stat.getFreeBytes();
            long usedBytes = totalBytes - freeBytes;
            double percentageUsed = (double) usedBytes / totalBytes * 100;

            TextView storageInfoTextView = findViewById(R.id.storageInfoText);
            ProgressBar storageProgressBar = findViewById(R.id.InternalProgressBar);
            TextView percentageStorageTextView = findViewById(R.id.percentageStorageText);

            if (storageInfoTextView != null && storageProgressBar != null && percentageStorageTextView != null) {
                storageInfoTextView.setText(String.format(Locale.getDefault(), getString(R.string._2f_gb_used_2f_gb_available_), usedBytes / (1024.0 * 1024.0 * 1024.0), freeBytes / (1024.0 * 1024.0 * 1024.0)));

                storageProgressBar.setProgress((int) percentageUsed);
                percentageStorageTextView.setText(String.format(Locale.getDefault(), "%.0f%%", percentageUsed));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    ////////////////////////// Panel Enc ////////////////////////////////////////

    

    
    

    ////////////////////////// Other ////////////////////////////////////////
    public static boolean isAppInstalled(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public void launchbypass() {



    }

   void runant(final String nf){
        excpp("/"+nf);
		}

	private void ExecuteElf(String shell) {
	try {
	Runtime.getRuntime().exec(shell);

        } catch (Exception e) {
            e.printStackTrace();
			}
			}
			public void excpp(String path) {
			try {
					ExecuteElf("chmod 777 " + getFilesDir() + path);
					ExecuteElf(getFilesDir() + path);
						ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
						ExecuteElf("su -c " + getFilesDir() + path);
					} catch (Exception e) {

        }
			}
    
    
public void launchbypassNoRoot() {
    Handler handler = new Handler(Looper.getMainLooper());

    // After 20 sec
    handler.postDelayed(() -> {
    //    runant("/ayan 2");
      //  runant("/ayan 7");

        // After another 30 sec
        handler.postDelayed(() -> {
     //       runant("/ayan 2");

            // After another 38 sec
            handler.postDelayed(() -> {
            //    runant("/ayan 2");
            }, 38_000);

        }, 30_000);

    }, 20_000);
}

    private void Loadssets() {
    //    MoveAssets(getFilesDir() + "/", "socs64");
        MoveAssets(getFilesDir() + "/", "sock64");
    //    MoveAssets(getFilesDir() + "/", "socs32");
   //     MoveAssets(getFilesDir() + "/", "socu32");
    //    MoveAssets(getFilesDir() + "/", "TW");
    //    MoveAssets(getFilesDir() + "/", "via.apk");
        MoveAssets(getFilesDir() + "/", "kernels64");
    }

    private boolean MoveAssets(String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String loadJSONFromAsset(String fileName) {
        String json = null;
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        stopPatcher();
        stopService(new Intent(MainActivity.get(), FloatService.class));
        stopService(new Intent(MainActivity.get(), Overlay.class));
        stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        stopService(new Intent(MainActivity.get(), ToggleAim.class));
        stopService(new Intent(MainActivity.get(), ToggleSimulation.class));
        stopService(new Intent(MainActivity.get(), FightMode.class));

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        return gestureDetector.onTouchEvent(event) || super.dispatchTouchEvent(event);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
            return;
        }

        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            super.onBackPressed();
            finishAffinity();
        } else {
            //  KToast.warningToast(MainActivity.this, getString(R.string.press_back_again_to_exit),
            //   Gravity.BOTTOM, KToast.LENGTH_AUTO);
            backPressedTime = System.currentTimeMillis();
        }
    }



    public LinearProgressIndicator getProgresBar() {
        if (progres == null) {
            progres = findViewById(R.id.progress);
        }
        return progres;
    }

    public void doShowProgress(boolean indeterminate) {
        if (progres == null) {
            return;
        }
        progres.setVisibility(View.VISIBLE);
        progres.setIndeterminate(indeterminate);

        if (!indeterminate) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                progres.setMin(0);
            }
            progres.setMax(100);
        }
    }

    public void doHideProgress() {
        if (progres == null) {
            return;
        }
        progres.setIndeterminate(true);
        progres.setVisibility(View.GONE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        } else {
            showSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (FloatService.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void startPatcher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(MainActivity.get())) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
            } else {
                startFloater();
            }
        }
    }

    private void startFloater() {
        
            startService(new Intent(MainActivity.get(), FloatService.class));
            loadAssets();
          //  startService(new Intent(MainActivity.get(), FightMode.class));
        } 

    private void stopPatcher() {
        stopService(new Intent(MainActivity.get(), FloatService.class));
        stopService(new Intent(MainActivity.get(), Overlay.class));
        stopService(new Intent(MainActivity.get(), ToggleAim.class));
        stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        stopService(new Intent(MainActivity.get(), ToggleSimulation.class));
        stopService(new Intent(MainActivity.get(), FightMode.class));
    }

   
    public void loadAssets() {
		String filepath =Environment.getExternalStorageDirectory() + "/Android/data/.tyb";
        FileOutputStream fos = null;
        try {
			fos = new FileOutputStream(filepath);
			byte[] buffer = "DO NOT DELETE".getBytes();
			fos.write(buffer, 0, buffer.length);
			fos.close();
        } catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		daemonPath =getFilesDir().toString() +"/sock64";
     //  libPath =getFilesDir().toString() +"/shayan";
		if(Shell.rootAccess()) {
			socket = "su -c " + daemonPath;
		} else {
			socket = daemonPath;
		}
		try {
			Runtime.getRuntime().exec("chmod 777 " + daemonPath);
			//Runtime.getRuntime().exec("chmod 777 " + libPath);
		} catch (IOException e) {
		}
	}

    // obb copy mathod


    

// ...

private class MyCopyTask extends AsyncTask<String, Integer, File> {
    AlertDialog dialog;
    String message;

    @Override
    protected void onPreExecute() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.WrapContentDialog);
        builder.setCancelable(false);
        View customLayout = getLayoutInflater().inflate(R.layout.dialog_pakgamerz_progress, null);
        builder.setView(customLayout);
        dialog = builder.create();

       
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        dialog.show();
    }

    @Override
    protected File doInBackground(String... params) {
        String sourcePath = params[0];
        File source = new File(sourcePath);
        String filename = sourcePath.substring(sourcePath.lastIndexOf("/") + 1);
        File destination = new File("/storage/emulated/0/SdCard/Android/obb/" + params[1] + "/" + filename);

        try {
          
            FileUtils.copy(source.getAbsolutePath(), destination.getAbsolutePath());
        } catch (Exception e) {
            message = e.getMessage();
        }

        return destination;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(File result) {
        if (result.exists()) {
            Toast.makeText(getApplicationContext(),
                    getApplicationContext().getString(R.string.obb_copied),
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(),
                    message,
                    Toast.LENGTH_LONG).show();
        }
        dialog.dismiss();
    }
}





    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // if (requestCode == Storage_Permission) {
        if (requestCode == REQUEST_PERMISSIONS) {
            if (!hasAllPermissionsGranted(grantResults)) {
                Toast.makeText(this, R.string.unable_to_get_storage_permission, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public boolean hasAllPermissionsGranted(@NonNull int[] grantResults) {
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false;
            }
        }
        return true;
    }

    void RunShell(String cmd) {
        try {
            Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // obb mathod end

    @Override
    protected void onResume() {
        super.onResume();
        CountTimerAccout();
        setFullScreen();
        boolean needsRecreate = getSharedPreferences("app_prefs", MODE_PRIVATE).getBoolean("needs_recreate", false);
        if (needsRecreate) {
            getSharedPreferences("app_prefs", MODE_PRIVATE).edit().putBoolean("needs_recreate", false).apply();
        }
    }

    private void setFullScreen() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }


    private void CountTimerAccout() {
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    handler.postDelayed(this, 1000);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    Date expiryDate = dateFormat.parse(EXP());

                    TextView keylicencedrawer = findViewById(R.id.keydisplay);

                    String fullKey = PASSKEY + ":" + USERKEY;
                    keylicencedrawer.setText(fullKey);

                    TextView Datetimer = findViewById(R.id.keyexpiry);
                    if (expiryDate != null) {
                        SimpleDateFormat std = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
                        Datetimer.setText(getString(R.string.expiry) + std.format(expiryDate));
                    }
                    long now = System.currentTimeMillis();
                    long distance = expiryDate.getTime() - now;
                    long days = distance / (24 * 60 * 60 * 1000);
                    long hours = distance / (60 * 60 * 1000) % 24;
                    long minutes = distance / (60 * 1000) % 60;
                    long seconds = distance / 1000 % 60;
                    if (distance < 0) {
                    } else {
                        TextView Hari = findViewById(R.id.days);
                        TextView Jam = findViewById(R.id.hours);
                        TextView Menit = findViewById(R.id.minutes);
                        TextView Detik = findViewById(R.id.second);
                        if (days > 0) {
                            Hari.setText(" " + String.format("%02d", days));
                        }
                        if (hours > 0) {
                            Jam.setText(" " + String.format("%02d", hours));
                        }
                        if (minutes > 0) {
                            Menit.setText(" " + String.format("%02d", minutes));
                        }
                        if (seconds > 0) {
                            Detik.setText(" " + String.format("%02d", seconds));
                        }
                    }
                    displayRamUsage();
                    displayStorageUsage();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        handler.postDelayed(runnable, 0);
    }



}
